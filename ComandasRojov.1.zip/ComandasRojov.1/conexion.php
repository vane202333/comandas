
<?php
    //Configuracion necesaria para acceder a la data base.

    
        $hostname = "localhost";
        $usuariodb = "root";
        $passwordb = "";
        $dbname = "cloudser_comanda";

        //Generando la conexion con el servidor
        $conectar = mysqli_connect($hostname,$usuariodb,$passwordb,$dbname); 
        return $conectar;
   
?>
