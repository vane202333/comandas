<?php 
	
	include 'conexion.php';

if ($conectar->connect_error) {
    die("Conexión fallida: " . $conectar->connect_error);
}

// Verificar si se enviaron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recuperar los valores del formulario
    $nombres = $_POST["nombres"];
    $ApellidoP = $_POST["ApellidoP"];
    $ApellidoM = $_POST["ApellidoM"];
    $CorreoElectronico = $_POST["CorreoElectronico"];
    $TelefonoCel = $_POST["TelefonoCel"];
    $Genero = $_POST["Genero"];
    $FechaNacimiento = $_POST["FechaNacimiento"];
    $Contrasena = $_POST["Contrasena"];
    $ValidarContrasena = $_POST["ValidarContrasena"];
    $Perfil = $_POST["Perfil"];

    // Validando Campos Llenos
    if (empty($nombres) || empty($ApellidoP) || empty($ApellidoM) || empty($CorreoElectronico) || empty($TelefonoCel) || empty($Genero) || empty($FechaNacimiento) ||empty($Contrasena) || empty($ValidarContrasena) || empty($Perfil)) {
        // Mostrar un mensaje de error si algún campo está vacío
        echo "Todos los campos son obligatorios";
    } else {
        
       // Obtener el último ID de la tabla donde va insertar 
       $resultado = $conectar->query("SELECT MAX(idusuarios) AS ultimo_id FROM usuarios");
       $fila = $resultado->fetch_assoc();
       $ultimo_id = $fila["ultimo_id"];

       // Incrementar el último ID obtenido
       $nuevo_id = $ultimo_id + 1;

       // Preparar la consulta de inserción
       $sentencia1 = $conectar->prepare("INSERT INTO usuarios (idusuarios, nombres, ApellidoP, ApellidoM, CorreoElectronico, TelefonoCel, Genero, FechaNacimiento, Contrasena, ValidarContrasena, Perfil) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
       if (!$sentencia1) {
           die("Error al preparar la consulta: " . $conectar->error);
       }

       // Vincular parámetros y ejecutar la consulta
       $sentencia1->bind_param("isssssssssi", $nuevo_id, $nombres, $ApellidoP, $ApellidoM, $CorreoElectronico, $TelefonoCel, $Genero, $FechaNacimiento, $Contrasena, $ValidarContrasena, $Perfil);
       $resultado1 = $sentencia1->execute();

       if ($resultado1) {
           echo "Los datos se han insertado correctamente en la base de datos.";
       } else {
           echo "Error al insertar datos en la base de datos: " . $sentencia1->error;
       }
   }
}

// Cerrar la conexión
$conectar->close();
?>