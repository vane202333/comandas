<?php 
	
	include 'conexion.php';

if ($conectar->connect_error) {
    die("Conexión fallida: " . $conectar->connect_error);
}

// Verificar si se enviaron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recuperar los valores del formulario
    $CorreoElectronico = $_POST["CorreoElectronico"];
    $Contrasena = $_POST["Contrasena"];

    // Consulta SQL para obtener los datos de la base de datos
    $sql = "SELECT * FROM usuarios WHERE CorreoElectronico = '$CorreoElectronico' AND Contrasena = '$Contrasena'";
 
    $result = $conectar->query($sql);

    // Verificar si se encontraron resultados
    if ($result->num_rows > 0) {
        // Los datos coinciden, redireccionar a formulario del menu dependiendo tipo de usuario

       // header("Location: splash.html");//MODIFICAR AQUI VAN LOS FORMUMLARIOS
        echo "Modificar AQUI DEBE MOSTRAR AL FORMULARIO MENU ";
        exit(); // ¡Importante! Asegúrate de salir del script después de redireccionar
    } else {
        // Los datos no coinciden, mostrar un mensaje de error
        
        echo "Los datos ingresados no coinciden con los registros de la base de datos.";
    }
}

// Cerrar la conexión
$conectar->close();
?>